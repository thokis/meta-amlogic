export SOCFAMILY=axg
