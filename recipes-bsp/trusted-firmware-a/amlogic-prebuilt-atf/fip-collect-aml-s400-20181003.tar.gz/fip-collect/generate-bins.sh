#!/usr/bin/env bash

# Package u-boot.bin (BL33) into the trusted firmware using the prebuilt
# binaries provided in the Amlogic BSP buildroot package

set -o errexit
set -o pipefail
set -o nounset
set -o xtrace

#1 is the Amlogic fip directory
#2 is u-boot.bin
#3 is the output directory
#4 is the output filename

FIPDIR=${1}
UBOOTBIN=${2}
OUT=${3}
OUTBIN=${4}

function fix_blx() {
	#bl2 file size 41K, bl21 file size 3K (file size not equal runtime size)
	#total 44K
	#after encrypt process, bl2 add 4K header, cut off 4K tail

	#bl30 limit 41K
	#bl301 limit 12K
	#bl2 limit 41K
	#bl21 limit 3K, but encrypt tool need 48K bl2.bin, so fix to 7168byte.

	declare blx_bin_limit=0
	declare blx01_bin_limit=0
	declare -i blx_size=0
	declare -i zero_size=0

	#$7:name flag
	if [ "$7" = "bl30" ]; then
		blx_bin_limit=40960   # PD#132613 2016-10-31 update, 41984->40960
		blx01_bin_limit=13312 # PD#132613 2016-10-31 update, 12288->13312
	elif [ "$7" = "bl2" ]; then
		blx_bin_limit=41984
		blx01_bin_limit=7168
	else
		echo "blx_fix name flag not supported!"
		exit 1
	fi

	# blx_size: blx.bin size, zero_size: fill with zeros
	blx_size=`du -b $1 | awk '{print int($1)}'`
	zero_size=$blx_bin_limit-$blx_size
	dd if=/dev/zero of=$2 bs=1 count=$zero_size
	cat $1 $2 > $3
	rm $2

	blx_size=`du -b $4 | awk '{print int($1)}'`
	zero_size=$blx01_bin_limit-$blx_size
	dd if=/dev/zero of=$2 bs=1 count=$zero_size
	cat $4 $2 > $5

	cat $3 $5 > $6

	rm $2
}

# This predone to avoid the python2 dep in poky dunfell
# /usr/bin/env python2 ${FIPDIR}/acs_tool.pyc ${FIPDIR}/bl2.bin ${OUT}/bl2_acs.bin ${FIPDIR}/acs.bin 0

fix_blx ${OUT}/bl2_acs.bin ${OUT}/zero_tmp ${OUT}/bl2_zero.bin ${FIPDIR}/bl21.bin ${OUT}/bl21_zero.bin ${OUT}/bl2_new.bin bl2
fix_blx ${FIPDIR}/bl30.bin ${OUT}/zero_tmp ${OUT}/bl30_zero.bin ${FIPDIR}/bl301.bin ${OUT}/bl301_zero.bin ${OUT}/bl30_new.bin bl30

${FIPDIR}/aml_encrypt --bl3sig --input ${OUT}/bl30_new.bin --output ${OUT}/bl30_new.bin.enc --level v3 --type bl30
${FIPDIR}/aml_encrypt --bl3sig --input ${FIPDIR}/bl31.img --output ${OUT}/bl31.img.enc --level v3 --type bl31
${FIPDIR}/aml_encrypt --bl3sig --input  ${UBOOTBIN} --output ${OUT}/bl33.bin.enc --level v3 --type bl33 --compress lz4
${FIPDIR}/aml_encrypt --bl2sig --input ${OUT}/bl2_new.bin --output ${OUT}/bl2.n.bin.sig
${FIPDIR}/aml_encrypt --bootmk --output ${OUT}/${OUTBIN} \
	     --bl2 ${OUT}/bl2.n.bin.sig \
	     --bl30 ${OUT}/bl30_new.bin.enc \
	     --bl31 ${OUT}/bl31.img.enc \
	     --bl33 ${OUT}/bl33.bin.enc \
	     --level v3
